def saludar():
    print("Hola te estoy saludando desde la funcion saludar del modulo saludos")

class Saludo():
    def __init__(self):
        print("Hola, te estoy saludando desde el init de la clase Saludo")