def despedirse():
    print("Adios, me estoy despidiendo desde la funcion del modulo despedidas")

class Despedida():
    def __init__(self):
        print("Adios, te estoy despidiendo desde el init de la clase Despedida")