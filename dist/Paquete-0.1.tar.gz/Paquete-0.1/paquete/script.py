from paquete.hola.saludos import saludar
saludar()