from setuptools import setup    

setup(
    name="Paquete",
    version="0.1",
    description="Este es un paquete ejemplo",
    author="Eddie Jesus",
    author_email="yo@hcosta.com",
    url="http://hcosta.info",
    scripts=[],
    packages=["paquete","paquete.adios","paquete.hola"]
)